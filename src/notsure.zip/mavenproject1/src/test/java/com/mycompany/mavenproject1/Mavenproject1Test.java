/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.mycompany.mavenproject1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

public class Mavenproject1Test {

    @Test
    public void testCheckUsername() {
        User obj = new User();
        assertTrue(obj.checkUsername("kosi_01"));
        assertFalse(obj.checkUsername("kosi"));
    }

    @Test
    public void testCheckPasswordComplex() {
        User obj = new User();
        assertTrue(obj.checkPasswordComplex("Password1!"));
        assertFalse(obj.checkPasswordComplex("password"));
    }

    @Test
    public void testRegisterUserSuccess() {
        User obj = new User();
        String result = obj.registerUser(
                "kosi_01", "Password1!", "Hlelolwe", "Manana", "+27838884567");
        assertEquals("User registered successfully.", result);
    }

    @Test
    public void testRegisterUserFailUsername() {
        User obj = new User();
        String result = obj.registerUser(
                "kosi", "Password1!", "Hlelolwe", "Manana", "+27838884567");
        assertFalse(result.equals("User registered successfully."));
    }

    @Test
    public void testRegisterUserFailPassword() {
        User obj = new User();
        String result = obj.registerUser(
                "kosi_01", "password", "Hlelolwe", "Manana", "+27838884567");
        assertFalse(result.equals("User registered successfully."));
    }

    @Test
    public void testRegisterUserFailCellphone() {
        User obj = new User();
        String result = obj.registerUser(
                "kosi_01", "Password1!", "Hlelolwe", "Manana", "0838884567");
        assertFalse(result.equals("User registered successfully."));
    }

    @Test
    public void testLoginUser() {
        User obj = new User();
        obj.registerUser("kosi_01", "Password1!", "Hlelolwe", "Manana", "+27838884567");
        assertTrue(obj.loginUser("kosi_01", "Password1!"));
        assertFalse(obj.loginUser("kosi_01", "wrongpass"));
    }

    @Test
    public void testReturnLoginStatus() {
        User obj = new User();
        obj.registerUser("kosi_01", "Password1!", "Hlelolwe", "Manana", "+27838884567");
        String result = obj.returnLoginStatus("kosi_01", "Password1!");
        assertTrue(result.contains("Hlelolwe"));
    }

    // ===== MESSAGE TESTS =====

    @Test
    public void testCheckMessageID() {
        Messages msg = new Messages("+27718693002",
                "Hi Mike, can you join us for dinner tonight?", "Developer");
        assertTrue(msg.checkMessageID(msg.MessageID));
    }

    @Test
    public void testCheckRecipientCell() {
        Messages msg = new Messages("+27718693002",
                "Hi Mike, can you join us for dinner tonight?", "Developer");
        assertEquals("Cellphone number successfully captured.",
                msg.checkRecipientCell("+27718693002"));
        assertFalse(msg.checkRecipientCell("08575975889")
                .equals("Cellphone number successfully captured."));
    }

    @Test
    public void testCreateMessageHash() {
        Messages msg = new Messages("+27718693002",
                "Hi Mike, can you join us for dinner tonight?", "Developer");
        String hash = msg.createMessageHash();
        assertNotNull(hash);
        assertTrue(hash.contains(":"));
    }

    @Test
    public void testCheckMessageLengthValid() {
        String result = Messages.checkMessageLength(
                "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Message ready to send.", result);
    }

    @Test
    public void testCheckMessageLengthExceeds() {
        String longMessage = "a".repeat(251);
        String result = Messages.checkMessageLength(longMessage);
        assertEquals("Please enter a message of less than 250 characters.",
                result);
    }

    @Test
    public void testReturnTotalMessages() {
        Messages msg = new Messages("+27718693002",
                "Hi Mike, can you join us for dinner tonight?", "Developer");
        msg.totalMessagesSent++;
        assertEquals(1, msg.returnTotalMessages());
    }

    // PART 3 TESTS 

    @Test
    public void testSentMessagesArrayCorrectlyPopulated() {
        Messages data = Messages.populateTestData();
        assertTrue(data.sentMessages.contains("Did you get the cake?"));
        assertTrue(data.sentMessages.contains("It is dinner time !"));
    }

    @Test
    public void testDisplayLongestMessage() {
        Messages data = Messages.populateTestData();
        String longest = "";
        for (String m : data.messagetexts) {
            if (m.length() > longest.length()) {
                longest = m;
            }
        }
        assertEquals(
                "Where are you? You are late! I have asked you to be on time.",
                longest);
    }

    @Test
    public void testSearchForMessageID() {
        Messages data = Messages.populateTestData();
        int index = -1;
        for (int i = 0; i < data.recipients.size(); i++) {
            if (data.recipients.get(i).equals("0838884567")) {
                index = i;
                break;
            }
        }
        assertNotEquals(-1, index);
        assertEquals("It is dinner time !", data.messagetexts.get(index));
    }

    @Test
    public void testSearchByRecipient() {
        Messages data = Messages.populateTestData();
        ArrayList<String> found = new ArrayList<>();
        for (int i = 0; i < data.recipients.size(); i++) {
            if (data.recipients.get(i).equals("+27838884567")) {
                found.add(data.messagetexts.get(i));
            }
        }
        assertTrue(found.contains(
                "Where are you? You are late! I have asked you to be on time."));
        assertTrue(found.contains("Ok, I am leaving without you."));
    }

    @Test
    public void testDeleteMessageByHash() {
        Messages data = Messages.populateTestData();
        String hashToDelete = null;
        for (int i = 0; i < data.messagetexts.size(); i++) {
            if (data.messagetexts.get(i).equals(
                    "Where are you? You are late! I have asked you to be on time.")) {
                hashToDelete = data.messageHashes.get(i);
                break;
            }
        }
        assertNotNull(hashToDelete);
        data.deleteMessage(hashToDelete);
        assertFalse(data.messagetexts.contains(
                "Where are you? You are late! I have asked you to be on time."));
    }
}