package com.mycompany.mavenproject1;

import java.util.Scanner;

public class Mavenproject1 {


    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        User user = new User();

        // REGISTRATION
        System.out.println("registrations");
        System.out.print("Enter First Name: ");
        String firstName = scan.nextLine();
        System.out.print("Enter Last Name: ");
        String lastName = scan.nextLine();
        System.out.print("Enter Username: ");
        String username = scan.nextLine();
        System.out.print("Enter Password: ");
        String password = scan.nextLine();
        System.out.print("Enter Cellphone Number : ");
        String cellphone = scan.nextLine();

        String regResult = user.registerUser(
                username, password, firstName, lastName, cellphone);
        System.out.println(regResult);

        if (!regResult.equals("User registered successfully.")) {
            System.out.println("Registration failed. Exiting.");
            return;
        }

        // LOGIN
        System.out.println("\nLOGIN ");
        System.out.print("Enter Username: ");
        String loginUsername = scan.nextLine();
        System.out.print("Enter Password: ");
        String loginPassword = scan.nextLine();

        String loginResult = user.returnLoginStatus(loginUsername, loginPassword);
        System.out.println(loginResult);
System.out.println("\nWelcome to QuickChat.");
        if (!user.loginUser(loginUsername, loginPassword)) {
            System.out.println("Login failed. Exiting.");
            return;
        }

        // message object
        Messages session = new Messages("", "", user.getFirstName());

        // loading messages in json
        session.loadStoredMessages();

       
        int choice;
        do {
            System.out.println("\n QUICKCHAT MENU ");
            System.out.println("1. Send Messages");
            System.out.println("2. open Sent Messages");
            System.out.println("3. Stored Messages");
            System.out.println("0. Exit");
            System.out.print("Enter option: ");
            choice = Integer.parseInt(scan.nextLine());

            switch (choice) {

                case 1:
                    System.out.print("\nHow many messages would you like to send? ");
                    int numMessages = Integer.parseInt(scan.nextLine());

                    for (int i = 1; i <= numMessages; i++) {
                        System.out.println("\nMESSAGE " + i );
                        System.out.print("Enter recipient cellphone number: ");
                        String recipientCell = scan.nextLine();
                        System.out.print("Type your message: ");
                        String text = scan.nextLine();

                        // checking message length before creating message
                        String lengthCheck = Messages.checkMessageLength(text);
                        System.out.println(lengthCheck);
                        if (!lengthCheck.equals("Message ready to send.")) {
                            continue;
                        }

                        //  object with new message details
                        session.cellPhoneno = recipientCell;
                        session.messageText = text;
                        session.MessageID = java.util.UUID.randomUUID()
                                .toString()
                                .replace("-", "")
                                .substring(0, 10);

                        if (session.checkMessageID(session.MessageID)) {
                            System.out.println("Message ID created successfully.");
                        } else {
                            System.out.println("Invalid Message ID.");
                        }

                        System.out.println(session.checkRecipientCell(recipientCell));
                        session.printMessageDetails();
                        System.out.println(session.sentMessage(scan));
                    }
                    break;

                case 2:
                    session.printMessages();
                    System.out.println("Total messages sent: "
                            + session.returnTotalMessages());
                    break;

                case 3:
                    manageMessages(scan, session);
                    break;

                case 0:
                    System.out.println("Thank you for using QuickChat. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid option. Please try again.");
            }

        } while (choice != 0);

        scan.close();
    }

    // manage messages sub menu
    private static void manageMessages(Scanner scan, Messages msg) {

        int choice;
        do {
            System.out.println("\n STORED MESSAGES MENU ");
            System.out.println("1. Display Senders and Recipients");
            System.out.println("2. Display Longest Stored Message");
            System.out.println("3. Search by Message ID");
            System.out.println("4. Search by Recipient");
            System.out.println("5. Delete Message by Hash");
            System.out.println("6. Display Full Message History");
            System.out.println("0. Return to Main Menu");
            System.out.print("Enter choice: ");
            choice = Integer.parseInt(scan.nextLine());

            switch (choice) {
                case 1:
                    msg.outputSenderAndUser();
                    break;
                case 2:
                    msg.outputLenghtyMessage();
                    break;
                case 3:
                    System.out.print("Enter Message ID: ");
                    String id = scan.nextLine();
                    msg.findMessageID(id);
                    break;
                case 4:
                    System.out.print("Enter Recipient Cellphone Number: ");
                    String recipient = scan.nextLine();
                    msg.searchUser(recipient);
                    break;
                case 5:
                    System.out.print("Enter Message Hash: ");
                    String hash = scan.nextLine();
                    msg.deleteMessage(hash);
                    break;
                case 6:
                    msg.MessageHistory();
                    break;
                case 0:
                    System.out.println("Returning to main menu.");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }

        } while (choice != 0);
    }
}