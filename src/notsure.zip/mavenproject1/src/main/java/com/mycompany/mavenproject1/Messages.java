/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.UUID;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import org.json.JSONObject;

public class Messages {

    String MessageID;
    String messageText;
    String cellPhoneno;
    String senderName;

    // array to store sent messages
    ArrayList<String> sentMessages = new ArrayList<>();
    // array to store message IDs
    ArrayList<String> messageIDs = new ArrayList<>();
    // array to store recipients
    ArrayList<String> recipients = new ArrayList<>();
    // array to store message texts
    ArrayList<String> messagetexts = new ArrayList<>();
    // array to store message hashes
    ArrayList<String> messageHashes = new ArrayList<>();
    // array for stored messages
    ArrayList<String> storedMessages = new ArrayList<>();
    // array for disregarded messages
    ArrayList<String> disregardedMessages = new ArrayList<>();
    // counter for total messages sent
    int totalMessagesSent = 0;
//constructor to cread random id
    public Messages(String cellPhoneno, String messageText, String senderName) {
        // generate unique 10 character message ID
        this.MessageID = UUID.randomUUID()
                .toString()
                .replace("-", "")
                .substring(0, 10);
        this.cellPhoneno = cellPhoneno;
        this.messageText = messageText;
        this.senderName = senderName;
    }

    // id must be 10 char
    public boolean checkMessageID(String MessageID) {
        return MessageID.length() == 10;
    }

    // checking recipient number
    public boolean cellPhoneno(String cellphone) {
        return cellphone.startsWith("+27") && cellphone.length() == 12;
    }

    // return result of cellphone validation
    public String checkRecipientCell(String cellPhoneno) {
        if (cellPhoneno(cellPhoneno)) {
            return "Cellphone number successfully captured.";
        } else {
            return "Cellphone number is incorrectly formatted or does not contain international code.";
        }
    }

    // check message does not exceed 250 characters
    public static String checkMessageLength(String message) {
        if (message.length() <= 250) {
            return "Message ready to send.";
        }
        int excess = message.length() - 250;
        return "Message exceeds 250 characters by " + excess
                + ", please reduce the size.";
    }

    // creating unique hash from message ID 
    public String createMessageHash() {
        String firstTwo = MessageID.substring(0, 2);
        String[] words = messageText.split(" ");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        return (firstTwo + ":" + firstWord + ":" + lastWord).toUpperCase();
    }

    // save message to JSON file via JsonStorage
    public void storeMessage() {
        JsonStorage.saveMessage(
                MessageID,
                cellPhoneno,
                createMessageHash(),
                messageText);
    }

    // load stored messages from JSON file into arrays
    public void loadStoredMessages() {
        try (BufferedReader reader = new BufferedReader(
                new FileReader("messages.json"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                JSONObject obj = new JSONObject(line);
                String text = obj.getString("Message");
                String recipient = obj.getString("User");
                String hash = obj.getString("MessageHash");
                String id = obj.getString("MessageID");
                storedMessages.add(text);
                recipients.add(recipient);
                messageHashes.add(hash);
                messageIDs.add(id);
                messagetexts.add(text);
            }
            System.out.println("Stored messages loaded successfully.");
        } catch (IOException e) {
            System.out.println("No stored messages file found.");
        }
    }

    // populating test data for unit tests
   public static Messages populateTestData() {
    Messages test = new Messages(
            "+27834557896", "Did you get the cake?", "Developer");
    test.messageIDs.add(test.MessageID);
    test.recipients.add(test.cellPhoneno);
    test.messagetexts.add(test.messageText);
    test.messageHashes.add(test.createMessageHash());
    test.sentMessages.add(test.messageText);
    test.totalMessagesSent++;

    Messages test2 = new Messages("+27838884567",
            "Where are you? You are late! I have asked you to be on time.",
            "Developer");
    test.messageIDs.add(test2.MessageID);
    test.recipients.add(test2.cellPhoneno);
    test.messagetexts.add(test2.messageText);
    test.messageHashes.add(test2.createMessageHash());
    test.storedMessages.add(test2.messageText);

    Messages test3 = new Messages("+27834484567",
            "Yohoooo, I am at your gate.", "Developer");
    test.messageIDs.add(test3.MessageID);
    test.recipients.add(test3.cellPhoneno);
    test.messagetexts.add(test3.messageText);
    test.messageHashes.add(test3.createMessageHash());
    test.disregardedMessages.add(test3.messageText);

    Messages test4 = new Messages(
            "0838884567", "It is dinner time !", "Developer");
    test.messageIDs.add(test4.MessageID);
    test.recipients.add(test4.cellPhoneno);
    test.messagetexts.add(test4.messageText);
    test.messageHashes.add(test4.createMessageHash());
    test.sentMessages.add(test4.messageText);
    test.totalMessagesSent++;

    Messages test5 = new Messages("+27838884567",
            "Ok, I am leaving without you.", "Developer");
    test.messageIDs.add(test5.MessageID);
    test.recipients.add(test5.cellPhoneno);
    test.messagetexts.add(test5.messageText);
    test.messageHashes.add(test5.createMessageHash());
    test.storedMessages.add(test5.messageText);

    return test;
}

    // sending store or disregard a message
    public String sentMessage(Scanner scan1) {
        System.out.println("\nOptions:");
        System.out.println("1. Send");
        System.out.println("2. Store");
        System.out.println("3. Disregard");
        int choice = scan1.nextInt();
        scan1.nextLine();

        messageIDs.add(MessageID);
        recipients.add(cellPhoneno);
        messagetexts.add(messageText);
        messageHashes.add(createMessageHash());

        if (choice == 1) {
            sentMessages.add(messageText);
            totalMessagesSent++;
            return "Message sent.";
        } else if (choice == 2) {
            storedMessages.add(messageText);
            storeMessage();
            return "Message stored.";
        } else if (choice == 3) {
            disregardedMessages.add(messageText);
            return "Message disregarded.";
        } else {
            return "Invalid option.";
        }
    }

    // show all sent messages
    public void printMessages() {
        System.out.println("\nSent Messages:");
        if (sentMessages.isEmpty()) {
            System.out.println("No messages have been sent.");
            return;
        }
        for (String message : sentMessages) {
            System.out.println(message);
        }
    }

    // return total number of sent messages
    public int returnTotalMessages() {
        return totalMessagesSent;
    }

    // showing details of current message
    public void printMessageDetails() {
        System.out.println("\n Message Details ");
        System.out.println("Message ID: " + MessageID);
        System.out.println("user: " + cellPhoneno);
        System.out.println("Message: " + messageText);
        System.out.println("Message Hash: " + createMessageHash());
    }

    // display all senders and recipients
    public void outputSenderAndUser() {
        if (storedMessages.isEmpty()) {
            System.out.println("\nNo stored messages found.");
            return;
        }
        System.out.println("\nStored Messages");
        for (int i = 0; i < recipients.size(); i++) {
            System.out.println("sender: " + senderName);
            System.out.println("recipient:" + recipients.get(i));
            System.out.println("");
        }
    }

    // find and display the longest stored message
    public void outputLenghtyMessage() {
        if (storedMessages.isEmpty()) {
            System.out.println("No stored messages found.");
            return;
        }
        String longest = storedMessages.get(0);
        for (String msg : storedMessages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }
        System.out.println("longest message");
        System.out.println(longest);
    }

    // search for a message by its ID
    public void findMessageID(String id) {
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(id)) {
                System.out.println("user:" + recipients.get(i));
                System.out.println("message: " + messagetexts.get(i));
                return;
            }
        }
        System.out.println(" ID does not exist");
    }

    // search all messages for a specific recipient
    public void searchUser(String User) {
        boolean found = false;
        for (int i = 0; i < recipients.size(); i++) {
            if (recipients.get(i).equals(User)) {
                System.out.println("message:" + messagetexts.get(i));
                found = true;
            }
        }
        if (!found) {
            System.out.println("messeage doesnt exist");
        }
    }

    // delete a message using its hash
    public void deleteMessage(String hash) {
    for (int i = 0; i < messageHashes.size(); i++) {
        if (messageHashes.get(i).equals(hash)) {
            String deleted = messagetexts.get(i);
            messageHashes.remove(i);
            messageIDs.remove(i);
            recipients.remove(i);
            messagetexts.remove(i);
            storedMessages.remove(deleted);
            System.out.println("Message: \"" + deleted
                    + "\" successfully deleted.");
            return;
        }
    }
    System.out.println("doesnt exist");
}
    // display full message history
    public void MessageHistory() {
        System.out.println("\nMESSAGE HISTORY");
        for (int i = 0; i < messageIDs.size(); i++) {
            System.out.println("message ID:" + messageIDs.get(i));
            System.out.println("user:" + recipients.get(i));
            System.out.println("message:" + messagetexts.get(i));
            System.out.println("Hash:" + messageHashes.get(i));
        }
    }
}