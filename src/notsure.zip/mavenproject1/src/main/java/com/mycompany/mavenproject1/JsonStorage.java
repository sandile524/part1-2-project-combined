package com.mycompany.mavenproject1;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import java.io.FileWriter;
import java.io.IOException;
import org.json.JSONObject;

public class JsonStorage {

    public static void saveMessage(
            String messageID,
            String cellPhoneno,
            String messageHash,
            String messageText) {

        try {
            // build JSON object using org.json
            JSONObject obj = new JSONObject();
            obj.put("MessageID", messageID);
            obj.put("User", cellPhoneno);
            obj.put("MessageHash", messageHash);
            obj.put("Message", messageText);

            FileWriter audit = new FileWriter("messages.json", true);
            audit.write(obj.toString() + "\n");
            audit.close();
            System.out.println("Message stored in file.");

        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }
}