package com.mycompany.mavenproject1;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
public class User {

    String username;
    String password;
    String cellphone;
    String firstName;
    String lastName;

    // check username contains underscore and is at least 5 characters
    public boolean checkUsername(String username) {
        return username.contains("_") && username.length() >= 5;
    }

    // check password meets complexity requirements
    public boolean checkPasswordComplex(String password) {
        String pattern = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[^a-zA-Z0-9]).{8,}$";
        return password.matches(pattern);
    }

    // check cellphone starts with +27 and is 12 characters
    public boolean cellPhoneno(String cellphone) {
        return cellphone.startsWith("+27") && cellphone.length() == 12;
    }

    // register user with all validations
    public String registerUser(String username, String password,
            String firstName, String lastName, String cellphone) {
        if (!checkUsername(username)) {
            return "Username is not correctly formatted. Please ensure your username contains an _ and is at least 5 characters long.";
        }
        if (!checkPasswordComplex(password)) {
            return "Password is not correctly formatted. Please ensure the password contains at least 8 characters, a capital letter, a number and a special character.";
        }
        if (!cellPhoneno(cellphone)) {
            return "Cellphone number incorrectly formatted or does not contain international code.";
        }
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.cellphone = cellphone;
        return "User registered successfully.";
    }

    // check login credentials match registered details
    public boolean loginUser(String username, String password) {
        return this.username != null
                && this.username.equals(username)
                && this.password.equals(password);
    }

    // return login status message
    public String returnLoginStatus(String username, String password) {
        if (loginUser(username, password)) {
            return "Welcome " + firstName + " " + lastName
                    + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // get first name
    public String getFirstName() {
        return firstName;
    }

    // get last name
    public String getLastName() {
        return lastName;
    }
}